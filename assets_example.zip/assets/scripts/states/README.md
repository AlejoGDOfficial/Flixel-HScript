# Custom States

Here you must put your Scripts with the extension “.hx” that are designed to be States

The first script to be executed will always be “Main.hx”, you can use it to configure things, e.g.