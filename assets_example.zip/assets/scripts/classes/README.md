# Custom Classes

Here you must put your Scripts with the extension “.hx” that are designed to be Classes